This module allows creating subscriptions that generate recurring
invoices or orders. It also enables the sale of products that generate
subscriptions.
