- [Tecnativa](https://www.tecnativa.com):

  > - Pedro M. Baeza
  > - Carlos Roca
  > - Víctor Martínez
  > - Carolina Fernandez
  > - Juan José Seguí


- Dave Lasley \<<dave@laslabs.com>\>

- Souheil Bejaoui \<<souheil.bejaoui@acsone.eu>\>
