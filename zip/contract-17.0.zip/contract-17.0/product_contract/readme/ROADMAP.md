- There's no support right now for computing the start date for the
  following recurrent types: daily, weekly and monthlylastday.