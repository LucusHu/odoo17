- Refactor all the onchanges that have business logic to computed
  write-able fields when possible. Keep onchanges only for UI purposes.
- Add tests.
