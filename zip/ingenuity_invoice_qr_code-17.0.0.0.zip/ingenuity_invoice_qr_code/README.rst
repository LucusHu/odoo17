========================
Ingenuity QR Code on Invoice
========================

This Module will allow to Generate QR Code for Invoice.
By using this module you can Generate QR Code for Invoice. Thae QR code will visible on Invoice form. 
You can also print the QR code on Invoice as well.


Odoo Version
=============
Odoo 17 Community Edition


Release Notes
=============

[17.0.0.0] :  Add Module


Installation
============

* Install the Application => Apps -> QR Code on Invoice (Technical Name: ingenuity_invoice_qr_code)

To install this module, you need to: 'CRM'

Download the module and add it to your Odoo addons folder. Afterward, log on to
your Odoo server and go to the Apps menu. Trigger the debug mode and update the
list by clicking on the "Update Apps List" link. Now install the module by
clicking on the install button.


Upgrade
=======

To upgrade this module, you need to:

Download the module and add it to your Odoo addons folder. Restart the server
and log on to your Odoo server. Select the Apps menu and upgrade the module by
clicking on the upgrade button.


Configuration
=============

There is Nothing to Configure


Credits
=======

Contributors
------------

* Ingenuity Info <contact@ingenuityinfo.in>


Author & Maintainer
-------------------

This module is maintained by the Ingenuity Info
