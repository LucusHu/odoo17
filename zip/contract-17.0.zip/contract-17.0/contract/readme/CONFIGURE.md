To view discount field in contract line, you need to set *Discount on
lines* in user access rights.

Contracts can be viewed on the portal (list and detail) if the user
logged into the portal is a follower of the contract.
