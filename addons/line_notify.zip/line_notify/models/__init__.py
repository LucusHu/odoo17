from . import res_config_settings
from . import res_users
from . import res_partner
from . import notify_category
