To use this module, you need to:

1.  Go to Invoicing \> Customers \> Customer Contracts and select or
    create a new contract.
2.  Check *Generate recurring invoices automatically*.
3.  Add a new recurring invoicing line.
4.  Select "Variable quantity" in column "Qty. type".
5.  Select "Project Timesheets", "Tasks Timesheets" or "Analytic Same
    Product" depending on your need.
