This module extends the functionality of contract_variable_quantity
adding several variable quantity formulas to allow to invoice lines from
Timesheet (Analytic Lines).
