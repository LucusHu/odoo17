To use this module, you need to:

1.  Go to Invoicing \> Customers \> Customers Contracts and select or create a new
    contract.
2.  Check *Generate recurring invoices automatically*.
3.  Mark the check "Invoice Pending Sales Orders".
4.  On each invoicing, system will check if there's any pending sales
    orders with same analyitic account and will append the lines to the
    invoice being generated.
