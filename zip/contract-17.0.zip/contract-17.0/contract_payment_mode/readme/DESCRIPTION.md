This module allows to set a payment mode on contract for creating the
invoices with this payment mode.
