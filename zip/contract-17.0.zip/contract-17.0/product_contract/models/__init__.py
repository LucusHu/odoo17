# Copyright 2017 LasLabs Inc.
# Copyright 2018 ACSONE SA/NV
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import contract
from . import contract_line
from . import product_template
from . import sale_order
from . import sale_order_line
from . import res_company
from . import res_config_settings
