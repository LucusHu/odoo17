1.  Log with an user having sale but not account permissions.
2.  Go to Sales \> Sales \> Contracts.
3.  Create a new record or edit another one.
