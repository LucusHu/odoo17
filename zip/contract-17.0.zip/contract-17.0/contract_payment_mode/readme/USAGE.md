1.  Go to *Invoicing \> Customers \> Customer Contracts*.
2.  Create one.
3.  Select a partner to which invoice.
4.  If the partner has a payment mode, this payment mode is selected
    here.
5.  If not, or if you want another payment mode, you can change it in
    the corresponding field.
6.  Add a product to invoice.
7.  If you create an invoice, new invoice will have the selected payment
    mode.
